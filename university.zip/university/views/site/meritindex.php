

<!-- views/student/add-student.php -->

<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var app\models\Student $model */

use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;

$this->title = 'Student merit';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

    

        <div class="row">
            <div class="col-lg-5">

                <h1>Calculated Merit Index</h1>

<p>Student 1 Merit Index: <?= $meritIndexStudent1 ?></p>
<p>Student 2 Merit Index: <?= $meritIndexStudent2 ?></p>


            </div>
        </div>

    <?php endif; ?>
</div>
