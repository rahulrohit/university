<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Student;
use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;

class StudentController extends Controller
{
    public function actionAddStudent()
    {
        $model = new Student();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            // The form data is valid, save it to the database
            $model->save();

            Yii::$app->session->setFlash('studentAdded', 'Student added successfully!');
            return $this->refresh();
        }

        return $this->render('form', [
            'model' => $model,
        ]);
    }
	
	 public function actionForm()
    {
          $model = new Student();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            // The form data is valid, save it to the database
            $model->save();

            Yii::$app->session->setFlash('studentAdded', 'Student added successfully!');
            return $this->refresh();
        }

        return $this->render('form', [
            'model' => $model,
        ]);
    }
	
	
	public function actionCalculateMeritIndex()
    {
        // Fetch student data from the database
        $student1 = Student::findOne(['id' => 1]); // Assuming Student 1 has id=1 in the database
        $student2 = Student::findOne(['id' => 2]); // Assuming Student 2 has id=2 in the database

        // Calculate Merit Index
        $meritIndexStudent1 = $this->calculateMeritIndex($student1->ug_marks, 0, $student1->sports_quota);
        $meritIndexStudent2 = $this->calculateMeritIndex($student2->ug_marks, $student2->specialization_marks, $student2->sports_quota);

        // Display the calculated Merit Index for each student
        return $this->render('meritindex', [
            'meritIndexStudent1' => $meritIndexStudent1,
            'meritIndexStudent2' => $meritIndexStudent2,
        ]);
    }
	
	
	 public function actionAbout()
    {
        return $this->render('meritindex');
    }
	

    private function calculateMeritIndex($ugMarks, $specializationMarks, $sportsQuota)
    {
        $normalizedUGMarks = $this->normalizeMarks($ugMarks, 1350); // Assuming 1350 is the max UG marks
        $normalizedSpecializationMarks = $this->normalizeMarks($specializationMarks, 1800); // Assuming 1800 is the max specialization marks

        $meritIndex = $normalizedUGMarks + (2 * $normalizedSpecializationMarks) + ($sportsQuota ? 20 : 0);

        return $meritIndex;
    }

    private function normalizeMarks($marksObtained, $maxMarks)
    {
        // Normalize marks to a scale of 500
        return ($marksObtained / $maxMarks) * 500;
    }
}
