<?php

namespace app\models;

use Yii;
use yii\base\Model;

/**
 * ContactForm is the model behind the contact form.
 */
class AddForm extends Model
{
		public $name;
		public $course;
		public $ug_marks;
		public $specialization_marks;
		public $sports_quota;
		//public $verifyCode;


    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['name', 'course', 'obtained_marks_X', 'ug_marks','specialization_marks','sports_quota'], 'required'],
           
        ];
    }

   
   
}
