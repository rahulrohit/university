<?php
namespace app\models;
 
use Yii;
 
class Student extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'students';
    }
     
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'course', 'ug_marks'], 'required'],
            [['name', 'course','specialization_marks','sports_quota'], 'string', 'max' => 100],
            [['ug_marks'], 'string', 'max' => 15]
        ];
    }   
}